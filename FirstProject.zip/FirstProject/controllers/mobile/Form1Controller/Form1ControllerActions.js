define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onclick defined for Button0c395fb8356554e **/
    AS_Button_i97c3300860e4f48a2b17daef2e9061e: function AS_Button_i97c3300860e4f48a2b17daef2e9061e(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("Form2");
        ntf.navigate();
    }
});